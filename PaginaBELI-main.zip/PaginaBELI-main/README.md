# Aviso Importante

Queremos informar a nuestros visitantes que algunas de las imágenes utilizadas en este sitio web no son de nuestra propiedad. Se han obtenido de diversas fuentes en línea y se utilizan únicamente con fines ilustrativos.

Respetamos los derechos de autor y creemos en el uso justo de las imágenes. Si eres el propietario de alguna de las imágenes y deseas que se retire o se acredite de manera diferente, por favor, ponte en contacto con nosotros.

Gracias por tu comprensión.
